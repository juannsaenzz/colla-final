const secretAccessKey="M+71LDEghlDFa+CYU0Auvr3rw2Z95t5D+2P9+KzL";
module.exports=secretAccessKey;
